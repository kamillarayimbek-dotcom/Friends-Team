
  # Create from Photo Template

  This is a code bundle for Create from Photo Template. The original project is available at https://www.figma.com/design/5VkHJzsmW7LUGeyZ9mQmL7/Create-from-Photo-Template.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  